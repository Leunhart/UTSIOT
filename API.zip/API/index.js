const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./connection');  
const response = require('./response');  

const app = express();
const port = 3000;

app.use(cors());  
app.use(bodyParser.json()); 

app.get('/', (req, res) => {
    const sql = "SELECT * FROM utsiot";  

    db.query(sql, (error, result) => {
        if (error) {
            return res.status(500).send("Error retrieving data from database");
        }
        
        response(200, result, "Data fetched successfully", res);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
