const response = (statusCode, data,  message, res) => {
    res.status(statusCode).json ({
        suhumax : 35,
        suhumin : 21,
        suhurata : 28.35,
        nilai_suhu_max_humid_max: data,
    })
}

module.exports = response